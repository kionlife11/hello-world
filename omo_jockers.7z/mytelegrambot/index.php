<?php

 	// bot api
	// my tg id 390291486
	// @thephoenixcs 276030143

	$token = "823428752:AAEjIKGHwQl1md3qiLJxmxXDXNK-AdqDXUY";

	//echo "bot api <b>823428752:AAEjIKGHwQl1md3qiLJxmxXDXNK-AdqDXUY</b><br>my tg id <b>390291486</b><br>@thephoenixcs <b>276030143</b>";
	/*
	if(fopen("https://api.telegram.org/bot" . $token . "/sendMessage?chat_id=" . $id . "&text=Hello+World", "r"))
		echo "success";
	else
		echo "error";
		*/
	if($_POST['typeForm'] == "sendMessageToTelegram"){
		$message = $_POST['messageText'];
		$id = $_POST['user_id'];
		if(fopen("https://api.telegram.org/bot" . $token . "/sendMessage?chat_id=" . $id . "&text=".$message, "r"))
			echo "success";
		else
			echo "error";
	}
	else if($_POST['typeForm'] == "showAnswer"){
		/*
		if(fopen("https://api.telegram.org/bot".$token."/getUpdates", "r"))
			//$answer = file_get_contents("https://api.telegram.org/bot".$token."/getUpdates", "r"));
			echo "success";
		else
			echo "error";
			*/
		$api = "https://api.telegram.org/bot".$token;
		// получаем данные
		$update = json_decode(file_get_contents("php://input"), TRUE);
		$message = $update["message"];
		// все команды
		$commands = array(
		  "всем привет"    => "Дратути",
		  "кто самый"    => "Без сомнения {$message['from']['first_name']} {$message['from']['last_name']}",
		);
		// не учитываем регистр
		$text_lower = mb_convert_case($message["text"], MB_CASE_LOWER);
		// искать команду будем по первым 200 символам.
		if (strlen($text_lower) > 200) $text_lower = substr($text_lower, 0, 200);
		// крутим текст сообщения от конца до 1го символа в поисках существующего ключа в $commands
		for ($i=0; $i < strlen($text_lower); $i++) {
		  $text_lower_new = substr($text_lower, 0, strlen($text_lower)-$i);
		  if (isset($commands[$text_lower_new])) {
		      $text_lower = $text_lower_new;
		      break;
		  }
		}
		// сам ответ
		if (isset($commands[$text_lower])) $answer = $commands[$text_lower];
		// отправляем ответ в чат
		if (!empty($answer)) file_get_contents("{$api}/sendmessage?chat_id={$message["chat"]["id"]}&text={$answer}");
	}
	else{
		echo "нечего нету";
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Отправить сообщение в чат</title>
	<link href="/bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css">
	<script type="text/javascript" src="/js/jqeury/jquery-3.4.0.js"></script>
	<script type="text/javascript" src="/bootstrap/js/bootstrap.js"></script>
</head>
<body>
<div class="col-lg-12 col-md-12">
	<div class="col-lg-12 col-md-12">
		<h5>Отправить сообщение в ЛС телеграма</h5>
	</div>
	<form method="post">
		<input type="hidden" name="typeForm" value="sendMessageToTelegram">
		chat id:
		<input type="text" name="user_id" placeholder="ex. 390291486" value="390291486"> <br>
		text:
		<input type="text" name="messageText" value="">
		<input type="submit" name="send" value="Отправить">
	</form>
</div>
<div class="col-lg-12 col-md-12">
	<div class="col-lg-12 col-md-12">
		<h5>Получить обновления от телеграма</h5>
		<form method="post">
			<input type="hidden" name="typeForm" value="showAnswer">
		   	<input type="submit" value="Посмотреть ответ">
		</form>
		<?php echo $answer; ?>
	</div>

</div>
</body>
</html>