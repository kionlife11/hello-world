<?php
// filename for export
$csv_filename = 'report_'.date('Ymd').'.csv';
// database variables
include('../../my_func/function.php'); // подключаем пользовательские функции
// Параметры подключения к БД
$serverName = "172.21.65.14, 1441";
$connectionOptions = array(
    "database" => "lifecell_omo_jokers",
    "uid" => "lifecell_omo_jokers",
    "pwd" => "su=it5iP"
);

// Проверка соединения с БД
$conn = sqlsrv_connect($serverName, $connectionOptions);
if ($conn === false) {
    die(formatErrors(sqlsrv_errors()));
}
// create empty variable to be filled with export data
$csv_export = '';
// query to get data from database
$query = "SELECT msisdn, date, user_name FROM dbo.omo_jokers ORDER BY date DESC";

$result = sqlsrv_query($conn, $query);
if ($result === false)
{
  die(formatErrors(sqlsrv_errors()));
}



$csv_export .= "msisdn;date;user;\n";

// loop through database query and fill export variable
while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
    // create line with field values
    $csv_export .= "\"".$row["msisdn"]."\";\"".date_format($row["date"], "Y-m-d H:i:s")."\";\"".$row["user_name"]."\";\n";
}
// Export the data and prompt a csv file for download
header("Content-type: text/x-csv; charset=utf-8");
header("Content-Disposition: attachment; filename=".$csv_filename);
echo($csv_export);

mysqli_close($con);
?>