<?php
    function formatErrors($errors)
    {
        // Display errors
        echo "Error information: <br/>";
        foreach ($errors as $error) {
            echo "SQLSTATE: ". $error['SQLSTATE'] . "<br/>";
            echo "Code: ". $error['code'] . "<br/>";
            echo "Message: ". $error['message'] . "<br/>";
        }
    }

    function get_user_browser()
    {
        $u_agent = $_SERVER['HTTP_USER_AGENT'];        $ub = '';
        if(preg_match('/MSIE/i',$u_agent))          {   $ub = "ie";     }
        elseif(preg_match('/Firefox/i',$u_agent))   {   $ub = "firefox";    }
        elseif(preg_match('/Safari/i',$u_agent))    {   $ub = "safari"; }
        elseif(preg_match('/Chrome/i',$u_agent))    {   $ub = "chrome"; }
        elseif(preg_match('/Flock/i',$u_agent)) {   $ub = "flock";      }
        elseif(preg_match('/Opera/i',$u_agent)) {   $ub = "opera";      }
      return $ub;

    }

    function check_admin($user){
        //короткий логин тех пользователей которым отображаем кнопку выгрузки отчета по жалобам на ОМО номера
        // PQ
        $accept_users = ["SParkhomenko","AChernenko","AKostenko", "IYeromina", "MTorkanevska", "ODobrovolska", "ONedbaiev","VPereviazko"];
        // TL
        array_push($accept_users, "AAleksandrov", "OChalyk", "AMaslonkin", "NBlyzniuk", "YDoronina", "YHuz", "Vhlushko", "ALadyka");
        $flag = false;
        for( $i = 0; $i<count($accept_users); $i++){
            if($user == $accept_users[$i]) $flag = true;
        }
        return $flag;
    }
?>