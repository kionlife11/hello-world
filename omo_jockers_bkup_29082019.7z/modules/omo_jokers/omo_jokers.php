<?php

    require_once('../../my_func/take_user_login.php'); // подключаемся к файлу где описано получение имени пользователя Windows
    $user = get_user_login(); // получаем имя пользователя

    include('../../my_func/function.php'); // подключаем пользовательские функции

    // Параметры подключения к БД
    $serverName = "172.21.65.14, 1441";
    $connectionOptions = array(
        "database" => "lifecell_omo_jokers",
        "uid" => "lifecell_omo_jokers",
        "pwd" => "su=it5iP"
    );

    // Проверка соединения с БД
    $conn = sqlsrv_connect($serverName, $connectionOptions);
    if ($conn === false) {
        die(formatErrors(sqlsrv_errors()));
    }



  $msisdn = $_POST['msisdn'];

  // Select Query
  if(isset($_POST['btn_search']))
  {
    $query = "SELECT msisdn, date, user_name FROM dbo.omo_jokers WHERE msisdn = ".$msisdn." AND date > '". date("Y-m-d H:i:s", strtotime("-15 days 3 hours")) ."' ORDER BY date";
    $result = sqlsrv_query($conn, $query);
    if ($result === false)
    {
      die(formatErrors(sqlsrv_errors()));
    }
  }
  elseif (isset($_POST['btn_add'])){
    $query = "
      INSERT INTO dbo.omo_jokers(msisdn, date,notification_number,user_name) VALUES
      (
        ".$msisdn.",
        '".date("Y-m-d H:i:s", strtotime("+3 hours"))."',
        1,
        '".$user."'
      )
    ";
    $result = sqlsrv_query($conn, $query);
    if ($result === false)
    {
      die(formatErrors(sqlsrv_errors()));
    }
    else
    {
      echo '<script>alert("Предупреждение для номера '.$msisdn.' успешно зафиксировано!")</script>';
    }
    // После того как добавили запись в БД, выводим записи из базы данных в таблице
    $query = "SELECT id, msisdn, date, notification_number, user_name FROM dbo.omo_jokers WHERE msisdn = ". $msisdn ." AND date > '". date("Y-m-d H:i:s", strtotime("-15 days 3 hours")) ."' ORDER BY date";
    $result = sqlsrv_query($conn, $query);
    if ($result === false)
    {
      die(formatErrors(sqlsrv_errors()));
    }
  }
  //php end
?>

<!DOCTYPE html>
<html>
<head>
    <title>OMO Jokers</title>
    <link rel="shortcut icon" href="../../favicon.ico" type="image/ico">
    <link href="../../bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../my_css/page.css" rel="stylesheet" rel="stylesheet">
</head>
<style type="text/css">
  .btn{
    background: rgba(128,128,128,0.2);
  }
  .btn:hover{
    background: rgb(128,128,128);
  }
  table{
    font-size: 10pt;
  }
</style>
<body>
  <div class="col-md-12 masthead">
    <form method="POST">
      <div class="col-md-12">
        <div class="col-md-3">
          <span class="masthead-brand"><a href="http://my_lifecell/"><img src="/img/global-bilgi-logo.png"></a></span>
        </div>
        <div class="col-md-2 col-md-offset-2">
          <input type="text" name="msisdn" id="msisdn" placeholder="Введите номер телефона в формате 380..." class="form-control" maxlength="12" onkeyup="check_valid_number()" required>
        </div>
        <div class="col-md-4 col-md-offset-1">
            <?php
              if(check_admin($user)){
                 echo '<button  type="submit" class="btn" onClick="document.location.href=\'excel.php\'">Экспорт в Excel</button>';
              }
            ?>
            <input class="btn" type="submit" value="Найти" id="btn_search" name="btn_search" >
            <input class="btn" type="submit" value="Добавить" id="btn_add" name="btn_add">
        </div>
      </div>
    </form>
  </div>
  <div class="site-wrapper">
    <div class="cover-container">
      <div class="inner cover">
        <table class="table table-dark">
          <thead>
            <tr>
                <td>Номер телефона</td>
                <td>Номер предупреждения</td>
                <td>Автор предупреждения</td>
                <td>Время</td>
            </tr>
          </thead>
          <tbody>
            <?php
              $count_notification = 1;
              while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)){
                echo '
                    <tr>
                      <td>'.$row['msisdn'].'</td>
                      <td>'.$count_notification.'</td>
                      <td>'.$row['user_name'].'</td>
                      <td>'.date_format($row['date'], 'Y-m-d H:i:s').'</td>
                    </tr>';
                    $count_notification++;
              }
              sqlsrv_free_stmt($query);
              sqlsrv_close($conn);
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <div class="mastfoot">
      <div class="footer">
        <marquee width="98%">&copy; 2019. for agents lifecell.</marquee>
      </div>
    </div>

  <!-- script-->

  <script src="../../js/jqeury/jquery-3.4.0.js"></script>
  <script src="../../js/jquery.inputmask.js"></script>
  <script type="text/javascript">
    window.onload = function()
    {
        block_firefox();
    }

    function block_firefox()
    {
      var browser = '<?php echo get_user_browser();?>';
      if(browser == 'firefox')
      {
        document.getElementById('btn_add').disabled = true;
      }
    }

    $(document).ready
    (
      function()
      {
        $("#msisdn").inputmask("380999999999");
        check_valid_number();
      }
    ); // маска ввода для поля номера

    function check_valid_number(){ //проверка на валидность номера телефона
      var msisdn = document.getElementById("msisdn").value;
      if(msisdn.indexOf('_') != -1 || msisdn == ''){
        document.getElementById('btn_add').disabled = true;
        document.getElementById('btn_search').disabled = true;
      }
      else{
        document.getElementById('btn_add').disabled = false;
        document.getElementById('btn_search').disabled = false;
        block_firefox();
      }
    }
</script>
</body>
</html>