<?php 

	require_once('../../my_func/take_user_login.php'); // подключаемся к файлу где описано получение имени пользователя Windows
    $user = get_user_login(); // получаем имя пользователя

    include('../../my_func/function.php'); // подключаем пользовательские функции
    
	  // Параметры подключения к БД  
	  $serverName = "172.21.65.14, 1441";
	  $connectionOptions = array(
	      "database" => "lifecell_omo_jokers",
	      "uid" => "lifecell_omo_jokers",
	      "pwd" => "su=it5iP"
	  );

	  // Проверка соединения с БД
	  $conn = sqlsrv_connect($serverName, $connectionOptions);
	  if ($conn === false) {
	      die(formatErrors(sqlsrv_errors()));
	  }

	  $typeForm = $_POST['typeForm'];
	  $curDate = date('j'); //номер дня в месяце

	  if($typeForm == 'saveForm'){

	  	$query = "
	  		INSERT INTO dbo.schedule(
	  			comment,
	  			tid,
	  			starttime
	  			)
	  		VALUES";

	  	$values = '';
	  	$arrMonitoringEvening = array();
	  	$arrMonitoringMorning = array();
	  	$arrStartMonitoringTime = array();
	  	$countDays = 0;
	  	foreach ($_POST as $key => $value) {
	  		foreach ($value as $key) {
	  			if($countDays <= 30) array_push($arrMonitoringMorning, $key);
	  			else if($countDays<=61) array_push($arrMonitoringEvening, $key);
	  			else array_push($arrStartMonitoringTime, "'".$key."'");
				//$values = $values.",(".$key.",".$key.",".$key.",".$countDays.")";
  				$countDays++;
	  		}
	  	}
	  	for($i = 0; $i<31; $i++){
	  		$values = $values.",(".$arrMonitoringMorning[$i].",".$arrMonitoringEvening[$i].",".$arrStartMonitoringTime[$i].")";

	  	}
	  	$values = substr($values, 1);
	  	echo $values;

	  	/*
	    $result = sqlsrv_query($conn, $query);
	    if ($result === false) 
	    {
	        die(formatErrors(sqlsrv_errors()));    
	    }
	    */
	  }
?>


<!DOCTYPE html>
<html>
<head>
	<title>Расписание inbound ТЛ</title>
	<link rel="shortcut icon" href="../../favicon.ico" type="image/ico">
    <link href="../../bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- <link href="../../my_css/page.css" rel="stylesheet" rel="stylesheet"> -->
   
    <script>
		
	</script>
	<style type="text/css">
		body {
		 	padding-top: 20px;
		 	background-color: #333;
		 	color: #fff;
  			text-align: center;
  			text-shadow: 0 1px 3px rgba(0,0,0,.5);
		}
		.starter-template {
		 	padding: 40px 15px;
		  	text-align: center;
		}
		.monitoring_time_style {
				background-color: rgb(125,186,0); 
				width: 104px;
				height: 23px;
				text-align: center;
				border:2px blue solid;		
		}
		th.vertical{
		  -webkit-transform: rotate(90deg); 
		  -moz-transform: rotate(90deg);
		  -ms-transform: rotate(90deg);
		  -o-transform: rotate(90deg);
		  transform: rotate(90deg);
		  height: auto;
		}
		option, select{
			color:black;
		}
		td, th {
			vertical-align: middle;
		}
	</style>
</head>
<body class="navbar-top">
	<!--
    <div class="navbar navbar-inverse navbar-fixed-top">
		<div class="navbar-header">
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav navbar-right" style="margin-top: 15px;">
					<img src="/../../img/globalbilgi.png" align="center" style="width: 120px; height: 30px; margin: -3px;margin-left:-10px">
				</ul> 
			</div>
		</div>
	</div>
	-->
    <div class="container">

      <div class="starter-template">
      	<?php print_r($_POST); ?>
        <h1>Bootstrap starter template</h1><br>
        <!--Monitoring TL-->
		<div class="col-lg-9 col-md-9 col-lg-offset-2 col-md-offset-2" style="margin-top: -10px">

			<div class="panel panel-default" style="border: none; height: 160px">
			  <div class="panel-body" style="padding: 4px">
			  	<div class="col-lg-12 col-md-12">
			  		<?php 
			  		
			  		$query = "
			  					SELECT 
			  						tl.tl_name 
			  					FROM 
			  						dbo.schedule AS sc, dbo.teamleader_info AS tl 
			  					WHERE 
			  						tl.id = sc.tid
			  					AND 
			  						sc.comment = '".$curDate."'
			  					AND 
			  						sc.starttime NOT LIKE '16'";
					    $result = sqlsrv_query($conn, $query);
					    if ($result === false) 
					    {
					      die(formatErrors(sqlsrv_errors()));
					    }

			  		?>
				  	<div class="col-md-3 col-lg-3" style=""><b class="monitoring_time_style">Сегодня мониторят:</b>
				  		<a href=\\172.21.24.64\webchat_lifecell\Project\My_lifecell\bin\js\Edit>
				  			<img src="img/monitoring/default.png" width="78" height="104" style="margin-top: 8%; margin-left: 20%" class="image_monitoring">
				  		</a>
				  	</div>
				  	<div class="col-md-2 col-lg-2">
				  		<div class="monitoring_time_style">
				  			<label style="font-size: 8pt;">Утро: 
				  				<label id="monitoring_time_morning_start">&nbsp;</label> - <label id="monitoring_time_morning_end">&nbsp;</label>
				  			</label>
				  			<img  width="94" height="130" class="image_monitoring" id="monitoring_TL_morning" style="margin-top: -10px;">
				  		</div>  		
				  	</div>
				  	<div class="col-md-2 col-lg-2">
				  		<div class="monitoring_time_style">
				  			<label style="font-size: 8pt;">Вечер: <label id="monitoring_time_evening_start">&nbsp;</label> - <label id="monitoring_time_evening_end">&nbsp;</label></label>
				  			<img width="94" height="130" class="image_monitoring" id="monitoring_TL_evening" style="margin-top: -10px;">
				  		</div>
				  		
				  	</div>
				  	<div class="col-md-2 col-lg-2">
				  		<div class="monitoring_time_style">
				  			<label style="font-size: 8pt;">Telesales</label>
				  			<img  width="94" height="130" class="image_monitoring" id="monitoring_TL_telesales" style="margin-top: -2px;">
				  		</div>
				  	</div>
				  	<div class="col-md-2 col-lg-2">
				  		<div>
				  			<img  width="150" height="150" src="img/info.png" style="margin-top: 5px; transform: rotate(15deg)">
				  		</div>									  		
				  	</div>
				  </div>
			  </div>
			</div>
		</div>
		<div class="col-lg-12 col-md-12">
			<br><br>
			<form method="post">
				<input type="hidden" name="typeForm" value="saveForm">
				<div class="table-responsive">
					<table class="table table-sm" style="font-size: 10pt;">
						<?php 
						$query = "SELECT DISTINCT 
									tl.tl_name,
									sc.starttime,
									sc.comment,
									tl.id 
								FROM 
									dbo.schedule AS sc,
									dbo.teamleader_info AS tl 
								WHERE 
									tl.id = sc.tid";
					    $result = sqlsrv_query($conn, $query);
					    if ($result === false) 
					    {
					      die(formatErrors(sqlsrv_errors()));
					    }
					    print_r($result);
						$day = 1;
						$year = date("Y");
						$month = date("m");
						echo "<thead'>
							<tr style=''>
								<th>Монитронг</th>";
						while($day<=31){
							if($day < 10) { echo "<th class=''>0".$day."</th>"; }
							else { echo "<th class=''>".$day."</th>";}
							$day++;
						}
						$day = 1;
						echo "</tr>
						</thead>
						<tbody>
							<tr>
								<td>УТРО</td>";	
							while($day<=31){

								echo "                                      
                                  <td>
                                  	<select name='monitoring_TL_morning[]'>
                                  		<option value='13'>Сергей Солонинка</option>
										<option value='15'>Евгения Доронина</option>
										<option value='16'>Алексей Чалык</option>
										<option value='17'>Артем Александров</option>
										<option value='18'>Анастасия Ладыка</option>
										<option value='19'>Артем Маслёнкин</option>
										<option value='20'>Алина Рябовол</option>
										<option value='21'>Владислав Глушко</option>
										<option value='22'>Елизавета Гузь</option>
                                  	</select>                                  
                                  </td>";
								$day++;
							}
							$day = 1;
							echo "</tr>
							<tr>
							<td>ВЕЧЕР</td>";
							while($day<=31){
								echo "<td>
									<select name='monitoring_TL_evening[]'>
										<option value='13'>Сергей Солонинка</option>
										<option value='15'>Евгения Доронина</option>
										<option value='16'>Алексей Чалык</option>
										<option value='17'>Артем Александров</option>
										<option value='18'>Анастасия Ладыка</option>
										<option value='19'>Артем Маслёнкин</option>
										<option value='20'>Алина Рябовол</option>
										<option value='21'>Владислав Глушко</option>
										<option value='22'>Елизавета Гузь</option>
									</select>
								</td>";
								$day++;
							}
							$day = 1;
							echo "</tr>
							<tr>
								<td> Начало вечернего мониторинга</td>";
								while($day<=31){
									echo "<td>
											<select class='custom-select custom-select-sm' name='starttime[]'>
												<option value='16' selected>16:20</option>
												<option value=''>14:00</option>
											</select>
										</td>";
									$day++;
								}
							echo "</tr>
						</tbody>";


						sqlsrv_free_stmt($query);
	                    sqlsrv_close($conn);
						?>
					</table>
				</div>
				<br>
				<input type='submit' name='send' value="Сохранить" class="btn btn-default">
			</form>
		</div>
      </div>

    </div><!-- /.container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="/js/jqeury/jquery-3.4.0.js"></script>
    <script src="../../bootstrap/bootstrap.js"></script>
</html>

