<?php
	include('/function.php'); // подключаем пользовательские функции

	function connect_to_db($host, $user, $password, $database){
	// Параметры подключения к БД
	  $serverName = "172.21.65.14, 1441";
	  $connectionOptions = array(
	      "database" => "lifecell_omo_jokers",
	      "uid" => "lifecell_omo_jokers",
	      "pwd" => "su=it5iP"
	  );

	  // Проверка соединения с БД
	  $conn = sqlsrv_connect($serverName, $connectionOptions);
	  if ($conn === false) {
	      die(formatErrors(sqlsrv_errors()));
	  }
	}


?>